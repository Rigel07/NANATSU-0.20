package com.nanatsu.chaos;

import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/** Hawk: cerdo companero que devora todo lo que le des, hace ruidos de cerdo e es inmortal. */
public class Hawk extends TamableAnimal {
    static final String[] MODES = {"Seguir", "Deambular (8 bloques)", "Deambular (16 bloques)", "Deambular (32 bloques)", "Quedarse quieto"};
    int hmode = 0;
    BlockPos center = null;
    int eaten = 0;

    public Hawk(EntityType<? extends TamableAnimal> t, Level l) {
        super(t, l);
    }

    public static AttributeSupplier.Builder attrs() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 20).add(Attributes.MOVEMENT_SPEED, 0.27)
                .add(Attributes.ATTACK_DAMAGE, 4).add(Attributes.FOLLOW_RANGE, 24);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.2, true));
        this.goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.2, 5, 2, false) {
            @Override public boolean canUse() { return Hawk.this.hmode == 0 && super.canUse(); }
            @Override public boolean canContinueToUse() { return Hawk.this.hmode == 0 && super.canContinueToUse(); }
        });
        this.goalSelector.addGoal(5, new WanderGoal());
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 1.0) {
            @Override public boolean canUse() { return !Hawk.this.isTame() && super.canUse(); }
        });
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 6f));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this));
    }

    class WanderGoal extends Goal {
        WanderGoal() { setFlags(EnumSet.of(Flag.MOVE)); }

        @Override
        public boolean canUse() {
            return isTame() && hmode >= 1 && hmode <= 3 && center != null && getNavigation().isDone() && getRandom().nextInt(40) == 0;
        }

        @Override
        public void start() {
            int r = hmode == 1 ? 8 : (hmode == 2 ? 16 : 32);
            int x = center.getX() + getRandom().nextInt(r * 2 + 1) - r;
            int z = center.getZ() + getRandom().nextInt(r * 2 + 1) - r;
            BlockPos t = level().getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
            getNavigation().moveTo(t.getX() + 0.5, t.getY(), t.getZ() + 0.5, 1.0);
        }
    }

    @Override
    public boolean isInvulnerableTo(DamageSource s) {
        return !s.is(DamageTypeTags.BYPASSES_INVULNERABILITY);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!level().isClientSide && getY() < level().getMinBuildHeight() - 10) {
            LivingEntity o = getOwner();
            if (o != null) teleportTo(o.getX(), o.getY(), o.getZ());
            else teleportTo(getX(), level().getMinBuildHeight() + 100, getZ());
            fallDistance = 0;
        }
    }

    @Override
    public InteractionResult mobInteract(Player p, InteractionHand h) {
        ItemStack s = p.getItemInHand(h);
        if (!s.isEmpty()) {
            if (!level().isClientSide) devour(s, p);
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (isTame() && isOwnedBy(p) && p.isShiftKeyDown()) {
            if (!level().isClientSide) {
                hmode = (hmode + 1) % MODES.length;
                if (hmode >= 1 && hmode <= 3) center = blockPosition();
                setOrderedToSit(hmode == 4);
                p.displayClientMessage(Component.literal("Hawk: " + MODES[hmode]), true);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (!level().isClientSide) playSound(SoundEvents.PIG_AMBIENT, 1f, 1.4f);
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    private void devour(ItemStack s, Player p) {
        ItemStack copy = s.copy();
        copy.setCount(1);
        if (!p.getAbilities().instabuild) s.shrink(1);
        playSound(SoundEvents.GENERIC_EAT, 1f, 1f);
        ((ServerLevel) level()).sendParticles(new ItemParticleOption(ParticleTypes.ITEM, copy), getX(), getY() + 0.4, getZ(), 8, 0.2, 0.2, 0.2, 0.05);
        eaten++;
        heal(2);
        p.displayClientMessage(Component.literal("¡Hawk devoro " + copy.getHoverName().getString() + "! (" + eaten + ")"), true);
        if (!isTame() && getRandom().nextInt(3) == 0) {
            tame(p);
            level().broadcastEntityEvent(this, (byte) 7);
            setPersistenceRequired();
        }
    }

    @Override public AgeableMob getBreedOffspring(ServerLevel l, AgeableMob o) { return null; }
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.PIG_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.PIG_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.PIG_DEATH; }
    @Override protected void playStepSound(BlockPos pos, BlockState st) { playSound(SoundEvents.PIG_STEP, 0.15f, 1f); }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putInt("HMode", hmode);
        t.putInt("Eaten", eaten);
        if (center != null) {
            t.putInt("CX", center.getX());
            t.putInt("CY", center.getY());
            t.putInt("CZ", center.getZ());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        hmode = t.getInt("HMode");
        eaten = t.getInt("Eaten");
        if (t.contains("CX")) center = new BlockPos(t.getInt("CX"), t.getInt("CY"), t.getInt("CZ"));
    }
}
