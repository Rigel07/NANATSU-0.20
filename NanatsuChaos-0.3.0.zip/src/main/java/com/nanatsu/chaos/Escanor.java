package com.nanatsu.chaos;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/** Escanor, duenio de la taberna de Liones. De dia su poder lo desborda. */
public class Escanor extends PathfinderMob {
    public Escanor(EntityType<? extends PathfinderMob> t, Level l) {
        super(t, l);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attrs() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 200).add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.ATTACK_DAMAGE, 20);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean isInvulnerableTo(DamageSource s) {
        return !s.is(DamageTypeTags.BYPASSES_INVULNERABILITY);
    }

    @Override
    public InteractionResult mobInteract(Player p, InteractionHand h) {
        if (!level().isClientSide && p instanceof ServerPlayer sp) {
            CompoundTag d = PD.t(sp);
            long now = level().getGameTime();
            if (now - d.getLong("escanor_gift") > 6000 || d.getLong("escanor_gift") > now) {
                d.putLong("escanor_gift", now);
                sp.addItem(new ItemStack(Items.COOKED_BEEF, 8));
                if (level().isDay()) {
                    sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 6000, 1));
                    sp.sendSystemMessage(Component.literal("§6Escanor: §f¡El sol brilla, y mi orgullo tambien! Toma, come y lucha."));
                } else {
                    sp.sendSystemMessage(Component.literal("§6Escanor: §fEs de noche... Toma algo de comer, amigo."));
                }
            } else {
                sp.sendSystemMessage(Component.literal("§6Escanor: §fYa te serví hace poco. Vuelve mas tarde."));
            }
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
}
