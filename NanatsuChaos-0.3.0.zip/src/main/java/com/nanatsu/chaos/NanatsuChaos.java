package com.nanatsu.chaos;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(NanatsuChaos.MODID)
public class NanatsuChaos {
    public static final String MODID = "nanatsuchaos";

    public NanatsuChaos() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        Reg.init(bus);
        bus.addListener(this::setup);
        bus.addListener(Reg::attributes);
        bus.addListener(Reg::spawns);
        MinecraftForge.EVENT_BUS.register(new Events());
    }

    private void setup(FMLCommonSetupEvent e) {
        e.enqueueWork(Net::register);
    }
}
