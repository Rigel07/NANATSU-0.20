package com.nanatsu.chaos;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Estado global (por mundo) de Cath Palug y de Excalibur. state: 0 sin aparecer, 1 gatito, 2 jefe, 3 derrotado. */
public class CathData extends SavedData {
    public int state = 0;
    public boolean excalibur = false;

    public static CathData get(MinecraftServer s) {
        return s.overworld().getDataStorage().computeIfAbsent(CathData::load, CathData::new, "nanatsu_cath");
    }

    public static CathData load(CompoundTag t) {
        CathData d = new CathData();
        d.state = t.getInt("state");
        d.excalibur = t.getBoolean("exc");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putInt("state", state);
        t.putBoolean("exc", excalibur);
        return t;
    }
}
