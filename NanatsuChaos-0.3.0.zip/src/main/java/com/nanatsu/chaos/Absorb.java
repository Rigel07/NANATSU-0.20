package com.nanatsu.chaos;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;

/** Absorcion y renuncia de Gracias / Mandamientos, fragmentos del Caos y experiencia de demonio. */
public final class Absorb {
    private Absorb() {}

    private static void give(ServerPlayer p, String itemId) {
        ItemStack st = new ItemStack(Reg.I.get(itemId).get());
        if (!p.getInventory().add(st)) p.drop(st, false);
    }

    public static boolean grace(ServerPlayer p, String id) {
        if (PD.race(p) == Race.NONE) return false;
        if (!PD.list(p, "cmds").isEmpty()) {
            Powers.msg(p, "§cDebes renunciar a tus Mandamientos antes de absorber una Gracia.");
            return false;
        }
        if (!PD.add(p, "graces", id)) {
            Powers.msg(p, "§cYa posees esa Gracia.");
            return false;
        }
        p.sendSystemMessage(Component.literal("§e§lHas absorbido la " + Powers.GRACE_NAME.get(id) + "."));
        p.level().playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1f, 1.2f);
        Passives.refresh(p);
        Net.sync(p);
        return true;
    }

    public static boolean cmd(ServerPlayer p, String id) {
        if (PD.race(p) == Race.NONE) return false;
        if (!PD.list(p, "graces").isEmpty()) {
            Powers.msg(p, "§cDebes renunciar a tus Gracias antes de absorber un Mandamiento.");
            return false;
        }
        if (!PD.add(p, "cmds", id)) {
            Powers.msg(p, "§cYa posees ese Mandamiento.");
            return false;
        }
        p.sendSystemMessage(Component.literal("§4§lHas absorbido el " + Powers.CMD_NAME.get(id) + ". §7" + Powers.CMD_RULE.get(id)));
        p.level().playSound(null, p.blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.PLAYERS, 0.4f, 1.5f);
        if (PD.race(p) == Race.DEMONIO) demonXp(p, 150);
        if (PD.list(p, "cmds").size() >= 10) {
            p.sendSystemMessage(Component.literal("§4§l¡Has reunido los 10 Mandamientos! Posees el poder supremo del Rey Demonio."));
        }
        Passives.refresh(p);
        Net.sync(p);
        return true;
    }

    public static void renounceGraces(ServerPlayer p) {
        List<String> g = new ArrayList<>(PD.list(p, "graces"));
        if (g.isEmpty()) return;
        for (String id : g) give(p, id);
        PD.setList(p, "graces", new ArrayList<>());
        Powers.msg(p, "Has renunciado a tus Gracias");
        Passives.refresh(p);
        Net.sync(p);
    }

    public static void renounceCmds(ServerPlayer p) {
        List<String> c = new ArrayList<>(PD.list(p, "cmds"));
        if (c.isEmpty()) return;
        for (String id : c) give(p, "mandamiento_" + id);
        PD.setList(p, "cmds", new ArrayList<>());
        Powers.msg(p, "Has renunciado a tus Mandamientos");
        Passives.refresh(p);
        Net.sync(p);
    }

    public static void fragments(ServerPlayer p, int n) {
        int old = PD.geti(p, "fragments");
        int now = old + n;
        PD.puti(p, "fragments", now);
        int gained = now / 50 - old / 50;
        for (int i = 0; i < gained; i++) Powers.grantRandom(p, 1, true);
        Powers.msg(p, "Fragmentos del Caos: " + now + " (proxima habilidad en " + (50 - now % 50) + ")");
        Net.sync(p);
    }

    public static void demonXp(ServerPlayer p, int x) {
        if (PD.race(p) != Race.DEMONIO) return;
        int oldLv = PD.demonLevel(p);
        PD.puti(p, "demonxp", PD.geti(p, "demonxp") + x);
        int lv = PD.demonLevel(p);
        if (lv > oldLv) {
            String m = lv == 2 ? "Se manifiesta tu Marca Demoniaca." : "Despiertas la Marca Demoniaca superior.";
            p.sendSystemMessage(Component.literal("§4§lNivel de demonio " + lv + ": §c" + m));
            p.level().playSound(null, p.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.PLAYERS, 0.8f, 0.7f);
            Passives.refresh(p);
        }
        Net.sync(p);
    }
}
