package com.nanatsu.chaos;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;

/** Items de poder: Gracias, Mandamientos, Documentos perdidos, Fragmentos del Caos y Excalibur. */
public final class Gifts {
    private Gifts() {}

    public static final Tier TIER = new Tier() {
        public int getUses() { return 0; }
        public float getSpeed() { return 9.0f; }
        public float getAttackDamageBonus() { return 0.0f; }
        public int getLevel() { return 4; }
        public int getEnchantmentValue() { return 30; }
        public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
    };

    static Item.Properties rare() {
        return new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant();
    }

    static void tip(List<Component> l, String s) {
        l.add(Component.literal("§7" + s));
    }

    public static class Grace extends Item {
        final String id;

        public Grace(String id) {
            super(rare());
            this.id = id;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp && Absorb.grace(sp, id)) s.shrink(1);
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide);
        }

        @Override
        public boolean isFoil(ItemStack s) { return true; }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) {
            tip(t, "Clic derecho para absorberla. Incompatible con los Mandamientos.");
        }
    }

    public static class Commandment extends Item {
        final String id;

        public Commandment(String id) {
            super(rare());
            this.id = id;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp && Absorb.cmd(sp, id)) s.shrink(1);
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide);
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) {
            tip(t, Powers.CMD_RULE.get(id));
            tip(t, "Clic derecho para absorberlo. Reune los 10 para el poder del Rey Demonio.");
        }
    }

    public static class Doc extends Item {
        final String id;
        final Race race;

        public Doc(String id, Race race) {
            super(new Item.Properties().stacksTo(1).rarity(Rarity.RARE));
            this.id = id;
            this.race = race;
        }

        @Override
        public boolean onEntitySwing(ItemStack stack, LivingEntity entity) {
            if (entity.level().isClientSide || !(entity instanceof ServerPlayer p)) return false;
            if (PD.race(p) != race) {
                Powers.msg(p, "§cSolo la raza " + race.label + " puede descifrar este documento.");
                return false;
            }
            if (!PD.add(p, "docs", id)) {
                Powers.msg(p, "§cYa conoces esta tecnica.");
                return false;
            }
            stack.shrink(1);
            p.sendSystemMessage(Component.literal("§6Has aprendido para siempre: §f" + Powers.ALL.get(id).name()));
            Net.sync(p);
            return true;
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) {
            tip(t, "Documento perdido de la raza " + race.label + ".");
            tip(t, "Clic izquierdo para aprenderlo (el documento desaparece).");
        }
    }

    public static class Fragment extends Item {
        public Fragment() {
            super(new Item.Properties().rarity(Rarity.RARE));
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp && PD.race(sp) != Race.NONE) {
                Absorb.fragments(sp, s.getCount());
                s.setCount(0);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide);
        }

        @Override
        public boolean isFoil(ItemStack s) { return true; }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) {
            tip(t, "Clic derecho para absorber el Caos. Cada 50 fragmentos: una habilidad.");
        }
    }

    public static class Excalibur extends SwordItem {
        public Excalibur() {
            super(TIER, 17, -2.0f, rare());
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            if (!l.isClientSide && p instanceof ServerPlayer sp && Powers.ready(sp, "excalibur", 100)) {
                Powers.ray(sp, sp.getLookAngle(), 40, 2.0, 120, net.minecraft.core.particles.ParticleTypes.END_ROD, false, true);
            }
            return InteractionResultHolder.sidedSuccess(p.getItemInHand(h), l.isClientSide);
        }

        @Override
        public boolean isFoil(ItemStack s) { return true; }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) {
            tip(t, "La espada legendaria. Unica arma capaz de danar a Cath Palug.");
            tip(t, "Otorga una habilidad del Caos de nivel 2 al encontrarla.");
        }
    }
}
