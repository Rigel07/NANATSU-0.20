package com.nanatsu.chaos;

import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/** Personajes del mundo de Nanatsu (Meliodas, Elizabeth, Diane, Ban, King, Gowther, Merlin). */
public class SinNpc extends PathfinderMob {
    static final EntityDataAccessor<String> WHO = SynchedEntityData.defineId(SinNpc.class, EntityDataSerializers.STRING);
    public static final String[] ALL = {"meliodas", "elizabeth", "diane", "ban", "king", "gowther", "merlin"};
    static final Map<String, String> NAME = Map.of("meliodas", "Meliodas", "elizabeth", "Elizabeth", "diane", "Diane",
            "ban", "Ban", "king", "King", "gowther", "Gowther", "merlin", "Merlin");

    public SinNpc(EntityType<? extends PathfinderMob> t, Level l) {
        super(t, l);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attrs() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 100).add(Attributes.MOVEMENT_SPEED, 0.25);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(WHO, "meliodas");
    }

    public String getWho() { return this.entityData.get(WHO); }

    public void setWho(String w) {
        this.entityData.set(WHO, w);
        setCustomName(Component.literal(NAME.getOrDefault(w, w)));
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.5));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean isInvulnerableTo(DamageSource s) {
        return !s.is(DamageTypeTags.BYPASSES_INVULNERABILITY);
    }

    private static void eff(ServerPlayer p, MobEffect m, int sec, int amp) {
        p.addEffect(new MobEffectInstance(m, sec * 20, amp));
    }

    @Override
    public InteractionResult mobInteract(Player pl, InteractionHand h) {
        if (level().isClientSide || !(pl instanceof ServerPlayer p)) return InteractionResult.sidedSuccess(level().isClientSide);
        String who = getWho();
        CompoundTag d = PD.t(p);
        String key = "npc_" + who;
        long now = level().getGameTime();
        String name = NAME.getOrDefault(who, who);
        if (now - d.getLong(key) < 24000 && d.getLong(key) <= now) {
            p.sendSystemMessage(Component.literal("§6" + name + ": §fVuelve mas tarde, ya te ayude hace poco."));
            return InteractionResult.CONSUME;
        }
        d.putLong(key, now);
        String line;
        switch (who) {
            case "meliodas" -> {
                p.addItem(new ItemStack(Items.COOKED_PORKCHOP, 4));
                eff(p, MobEffects.DAMAGE_BOOST, 300, 0);
                line = "¡Bienvenido a la Taberna del Sombrero del Jabali! Toma, la casa invita.";
            }
            case "elizabeth" -> {
                p.setHealth(p.getMaxHealth());
                eff(p, MobEffects.REGENERATION, 30, 1);
                line = "Que la diosa te proteja. ¡Cuidate mucho!";
            }
            case "diane" -> {
                eff(p, MobEffects.DAMAGE_RESISTANCE, 300, 0);
                p.addItem(new ItemStack(Items.COOKIE, 8));
                line = "¡Hola! ¿Has visto a Hawk? Siempre se escapa a comer...";
            }
            case "ban" -> {
                eff(p, MobEffects.MOVEMENT_SPEED, 300, 1);
                p.addItem(new ItemStack(Items.GOLDEN_APPLE, 1));
                line = "Vaya, otro humano con ganas de problemas. Me caes bien.";
            }
            case "king" -> {
                eff(p, MobEffects.LUCK, 300, 1);
                line = "...zzz... ¿eh? Ah, hola. Que flores tan bonitas hay hoy.";
            }
            case "gowther" -> {
                eff(p, MobEffects.NIGHT_VISION, 300, 0);
                line = "He leido tu corazon. Un espectaculo bastante interesante.";
            }
            default -> {
                if (getRandom().nextInt(4) == 0) p.addItem(new ItemStack(Reg.FRAGMENT.get(), 1));
                else p.addItem(new ItemStack(Items.AMETHYST_SHARD, 4));
                line = "Los hilos del destino te han traido hasta mi. Aprovechalo.";
            }
        }
        p.sendSystemMessage(Component.literal("§6" + name + ": §f" + line));
        return InteractionResult.CONSUME;
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putString("Who", getWho());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        if (t.contains("Who")) setWho(t.getString("Who"));
    }
}
