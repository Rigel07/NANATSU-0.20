package com.nanatsu.chaos;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.common.ForgeMod;

/** Atributos y efectos pasivos de razas, Gracias, Mandamientos y marcas demoniacas. */
public final class Passives {
    private Passives() {}

    static UUID uid(String s) {
        return UUID.nameUUIDFromBytes(("nanatsuchaos:" + s).getBytes(StandardCharsets.UTF_8));
    }

    static final UUID U_ATK = uid("atk"), U_HP = uid("hp"), U_ARM = uid("arm"), U_TGH = uid("tgh"),
            U_KB = uid("kb"), U_SPD = uid("spd"), U_LUCK = uid("luck"), U_REACH = uid("reach");

    static void attr(ServerPlayer p, Attribute a, UUID id, double amt, AttributeModifier.Operation op) {
        AttributeInstance in = p.getAttribute(a);
        if (in == null) return;
        AttributeModifier cur = in.getModifier(id);
        if (Math.abs(amt) < 1e-6) {
            if (cur != null) in.removeModifier(id);
            return;
        }
        if (cur != null && Math.abs(cur.getAmount() - amt) < 1e-6) return;
        if (cur != null) in.removeModifier(id);
        in.addTransientModifier(new AttributeModifier(id, "nanatsuchaos", amt, op));
    }

    static void fx(ServerPlayer p, MobEffect m, int amp) {
        p.addEffect(new MobEffectInstance(m, 260, amp, true, false, false));
    }

    static void fxOnce(ServerPlayer p, MobEffect m, int amp) {
        if (!p.hasEffect(m)) p.addEffect(new MobEffectInstance(m, 1200, amp, true, false, false));
    }

    public static void refresh(ServerPlayer p) {
        Race r = PD.race(p);
        double atk = 0, hp = 0, arm = 0, tgh = 0, kb = 0, spd = 0, luck = 0, reach = 0;
        boolean day = p.level().isDay();
        boolean sun = day && p.level().canSeeSky(p.blockPosition());
        List<String> g = PD.list(p, "graces");
        List<String> c = PD.list(p, "cmds");
        float before = p.getMaxHealth();

        switch (r) {
            case HUMANO -> {
                luck += 2; hp += 4; spd += 0.05;
                if (p.getHealth() < 6) fx(p, MobEffects.REGENERATION, 1);
            }
            case GIGANTE -> {
                hp += 20; atk += 4; kb += 0.6; arm += 4; reach += 1.5; spd -= 0.05;
            }
            case DEMONIO -> {
                atk += 4; hp += 6; spd += 0.08;
                if (!day) { atk += 4; fx(p, MobEffects.DAMAGE_BOOST, 0); }
                int lv = PD.demonLevel(p);
                if (lv >= 2) {
                    atk += 6; hp += 10; spd += 0.08;
                    fx(p, MobEffects.REGENERATION, 0);
                    Powers.sp(p, ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY() + 1.2, p.getZ(), 6, 0.35, 0.01);
                }
                if (lv >= 3) {
                    atk += 14; hp += 30; spd += 0.15; arm += 6;
                    fx(p, MobEffects.DAMAGE_RESISTANCE, 0);
                    fx(p, MobEffects.FIRE_RESISTANCE, 0);
                    Powers.sp(p, ParticleTypes.LARGE_SMOKE, p.getX(), p.getY() + 1.2, p.getZ(), 6, 0.4, 0.01);
                }
            }
            case HADA -> {
                hp -= 4; spd += 0.15; luck += 3;
                fx(p, MobEffects.JUMP, 1);
                fx(p, MobEffects.SLOW_FALLING, 0);
                fx(p, MobEffects.NIGHT_VISION, 0);
            }
            case DIOSA -> {
                hp += 14; arm += 2; luck += 1;
                fx(p, MobEffects.REGENERATION, 0);
                fx(p, MobEffects.FIRE_RESISTANCE, 0);
            }
            default -> { }
        }

        if (g.contains("gracia_sol")) {
            atk += 50; hp += 80; arm += 20; tgh += 8; kb += 1; spd += 0.3;
            fx(p, MobEffects.REGENERATION, 2);
            fx(p, MobEffects.FIRE_RESISTANCE, 0);
            fx(p, MobEffects.DAMAGE_RESISTANCE, 1);
            fx(p, MobEffects.NIGHT_VISION, 0);
            for (LivingEntity e : Powers.n(p, 10)) {
                e.setSecondsOnFire(4);
                Powers.melee(p, e, sun ? 12 : 4);
            }
        }
        if (g.contains("gracia_brillo")) {
            atk += 18; hp += 30; arm += 6; spd += 0.25;
            fx(p, MobEffects.REGENERATION, 1);
            fx(p, MobEffects.DAMAGE_RESISTANCE, 0);
            fx(p, MobEffects.NIGHT_VISION, 0);
            for (LivingEntity e : Powers.n(p, 12)) {
                e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 80, 0));
                Powers.melee(p, e, 2);
            }
        }
        if (g.contains("gracia_oceano")) {
            atk += 16; hp += 30; arm += 8;
            fx(p, MobEffects.WATER_BREATHING, 0);
            fx(p, MobEffects.DOLPHINS_GRACE, 0);
            fx(p, MobEffects.CONDUIT_POWER, 0);
            fx(p, MobEffects.REGENERATION, 0);
            fx(p, MobEffects.DAMAGE_RESISTANCE, 0);
            if (p.isInWater()) { spd += 0.3; fx(p, MobEffects.DAMAGE_BOOST, 1); }
        }
        if (g.contains("gracia_viento")) {
            atk += 14; hp += 24; spd += 0.4;
            fx(p, MobEffects.SLOW_FALLING, 0);
            fx(p, MobEffects.JUMP, 2);
            fx(p, MobEffects.REGENERATION, 0);
        }

        for (String id : c) {
            atk += 2.5; hp += 4;
            switch (id) {
                case "verdad" -> {
                    fx(p, MobEffects.NIGHT_VISION, 0);
                    for (LivingEntity e : Powers.n(p, 20)) e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0));
                }
                case "pureza" -> Powers.cleanse(p);
                case "amor" -> {
                    fx(p, MobEffects.REGENERATION, 1);
                    fxOnce(p, MobEffects.ABSORPTION, 0);
                    for (LivingEntity e : Powers.n(p, 12)) e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 9));
                }
                case "piedad" -> { fx(p, MobEffects.MOVEMENT_SPEED, 0); fx(p, MobEffects.DAMAGE_BOOST, 0); }
                case "pacifismo" -> fx(p, MobEffects.DAMAGE_RESISTANCE, 1);
                case "reposo" -> { fx(p, MobEffects.SATURATION, 0); fx(p, MobEffects.REGENERATION, 0); }
                case "fe" -> { fx(p, MobEffects.DAMAGE_BOOST, 0); kb += 0.3; }
                case "silencio" -> { fx(p, MobEffects.MOVEMENT_SPEED, 0); fx(p, MobEffects.JUMP, 0); fx(p, MobEffects.NIGHT_VISION, 0); }
                case "desinteres" -> { arm += 10; tgh += 4; kb += 0.4; }
                case "paciencia" -> { fx(p, MobEffects.DAMAGE_RESISTANCE, 0); fxOnce(p, MobEffects.ABSORPTION, 1); }
                default -> { }
            }
        }
        if (c.size() >= 10) {
            atk += 25; hp += 60; arm += 10; spd += 0.2;
            fx(p, MobEffects.REGENERATION, 1);
            fx(p, MobEffects.DAMAGE_RESISTANCE, 1);
            fx(p, MobEffects.FIRE_RESISTANCE, 0);
        }

        attr(p, Attributes.ATTACK_DAMAGE, U_ATK, atk, AttributeModifier.Operation.ADDITION);
        attr(p, Attributes.MAX_HEALTH, U_HP, hp, AttributeModifier.Operation.ADDITION);
        attr(p, Attributes.ARMOR, U_ARM, arm, AttributeModifier.Operation.ADDITION);
        attr(p, Attributes.ARMOR_TOUGHNESS, U_TGH, tgh, AttributeModifier.Operation.ADDITION);
        attr(p, Attributes.KNOCKBACK_RESISTANCE, U_KB, kb, AttributeModifier.Operation.ADDITION);
        attr(p, Attributes.MOVEMENT_SPEED, U_SPD, spd, AttributeModifier.Operation.MULTIPLY_TOTAL);
        attr(p, Attributes.LUCK, U_LUCK, luck, AttributeModifier.Operation.ADDITION);
        attr(p, ForgeMod.ENTITY_REACH.get(), U_REACH, reach, AttributeModifier.Operation.ADDITION);

        float after = p.getMaxHealth();
        if (after > before) p.heal(after - before);
        if (p.getHealth() > after) p.setHealth(after);
    }
}
