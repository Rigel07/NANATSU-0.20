package com.nanatsu.chaos;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Estructuras colocadas por codigo (statues, Liones, bosque del Rey Hada, Excalibur...). */
public final class Worldgen {
    private Worldgen() {}

    static BlockState s(net.minecraft.world.level.block.Block b) { return b.defaultBlockState(); }

    static void set(WorldGenLevel l, BlockPos p, BlockState st) { l.setBlock(p, st, 2); }

    static void box(WorldGenLevel l, BlockPos o, int x1, int y1, int z1, int x2, int y2, int z2, BlockState st) {
        for (int x = x1; x <= x2; x++)
            for (int y = y1; y <= y2; y++)
                for (int z = z1; z <= z2; z++)
                    set(l, o.offset(x, y, z), st);
    }

    static void air(WorldGenLevel l, BlockPos o, int x1, int y1, int z1, int x2, int y2, int z2) {
        box(l, o, x1, y1, z1, x2, y2, z2, s(Blocks.AIR));
    }

    static boolean flat(WorldGenLevel l, BlockPos o, int r, int tol) {
        int[][] pts = {{-r, -r}, {r, -r}, {-r, r}, {r, r}, {0, 0}};
        for (int[] q : pts) {
            int h = l.getHeight(Heightmap.Types.WORLD_SURFACE_WG, o.getX() + q[0], o.getZ() + q[1]);
            if (Math.abs(h - o.getY()) > tol) return false;
        }
        return l.getFluidState(o.below()).isEmpty() && l.getFluidState(o).isEmpty();
    }

    /** Plataforma circular con relleno por debajo y espacio libre por encima. */
    static void platform(WorldGenLevel l, BlockPos o, int r, BlockState top) {
        for (int x = -r; x <= r; x++)
            for (int z = -r; z <= r; z++) {
                if (x * x + z * z > r * r) continue;
                set(l, o.offset(x, -1, z), top);
                for (int y = -2; y >= -5; y--) set(l, o.offset(x, y, z), s(Blocks.DIRT));
                for (int y = 0; y <= 5; y++) set(l, o.offset(x, y, z), s(Blocks.AIR));
            }
    }

    static void pad(WorldGenLevel l, BlockPos o, int x1, int z1, int x2, int z2, BlockState top) {
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                set(l, o.offset(x, -1, z), top);
                for (int y = -2; y >= -5; y--) set(l, o.offset(x, y, z), s(Blocks.DIRT));
            }
    }

    static <T extends Mob> void spawn(WorldGenLevel l, EntityType<T> t, double x, double y, double z) {
        T m = t.create(l.getLevel());
        if (m == null) return;
        m.moveTo(x, y, z, l.getRandom().nextFloat() * 360f, 0f);
        m.finalizeSpawn(l, l.getCurrentDifficultyAt(BlockPos.containing(x, y, z)), MobSpawnType.STRUCTURE, null, null);
        m.setPersistenceRequired();
        l.addFreshEntity(m);
    }

    static void npc(WorldGenLevel l, String who, double x, double y, double z) {
        SinNpc n = Reg.SIN_NPC.get().create(l.getLevel());
        if (n == null) return;
        n.moveTo(x, y, z, l.getRandom().nextFloat() * 360f, 0f);
        n.setWho(who);
        n.finalizeSpawn(l, l.getCurrentDifficultyAt(BlockPos.containing(x, y, z)), MobSpawnType.STRUCTURE, null, null);
        l.addFreshEntity(n);
    }

    static void chest(WorldGenLevel l, BlockPos p, String table) {
        set(l, p, s(Blocks.CHEST));
        BlockEntity be = l.getBlockEntity(p);
        if (be instanceof RandomizableContainerBlockEntity c) {
            c.setLootTable(new ResourceLocation(NanatsuChaos.MODID, "chests/" + table), l.getRandom().nextLong());
        }
    }

    static BlockState leaf(net.minecraft.world.level.block.Block b) {
        return b.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
    }

    static void sphere(WorldGenLevel l, BlockPos o, int cx, int cy, int cz, int rad) {
        RandomSource r = l.getRandom();
        BlockState[] lv = {leaf(Blocks.AZALEA_LEAVES), leaf(Blocks.FLOWERING_AZALEA_LEAVES), leaf(Blocks.CHERRY_LEAVES)};
        for (int dx = -rad; dx <= rad; dx++)
            for (int dy = -rad; dy <= rad; dy++)
                for (int dz = -rad; dz <= rad; dz++) {
                    if (dx * dx + dy * dy + dz * dz > rad * rad || r.nextInt(12) == 0) continue;
                    BlockPos p = o.offset(cx + dx, cy + dy, cz + dz);
                    if (!l.getBlockState(p).isAir()) continue;
                    set(l, p, r.nextInt(70) == 0 ? s(Blocks.SHROOMLIGHT) : lv[r.nextInt(3)]);
                }
    }

    /** El Gran Arbol Sagrado de las hadas: tronco hueco con camara, raices, ramas y copa enorme. */
    static void sacredTree(WorldGenLevel l, BlockPos o) {
        RandomSource r = l.getRandom();
        int h = 58;
        BlockState log = s(Blocks.OAK_LOG);
        for (int y = 0; y < h; y++) {
            double rad = y < 8 ? 6.0 - y * 0.25 : (y < 40 ? 4.0 - (y - 8) * 0.03 : 3.0 - (y - 40) * 0.05);
            rad = Math.max(rad, 2.0);
            int R = (int) Math.ceil(rad);
            for (int dx = -R; dx <= R; dx++)
                for (int dz = -R; dz <= R; dz++) {
                    double d2 = dx * dx + dz * dz;
                    if (d2 > rad * rad) continue;
                    boolean hollow = y >= 1 && y <= 8 && d2 <= 2.6 * 2.6;
                    set(l, o.offset(dx, y, dz), hollow ? s(Blocks.AIR) : (r.nextInt(40) == 0 ? s(Blocks.SHROOMLIGHT) : log));
                }
        }
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++)
                if (dx * dx + dz * dz <= 6) set(l, o.offset(dx, 0, dz), s(Blocks.MOSS_BLOCK));
        air(l, o, -1, 1, 2, 1, 3, 6);
        set(l, o.offset(0, 9, 0), s(Blocks.SHROOMLIGHT));
        for (int i = 0; i < 7; i++) {
            double a = Math.PI * 2 * i / 7 + 0.3;
            for (int t = 4; t <= 12; t++) {
                int x = (int) Math.round(Math.cos(a) * t), z = (int) Math.round(Math.sin(a) * t);
                int hh = t < 7 ? 2 : (t < 10 ? 1 : 0);
                for (int y = -1; y <= hh; y++) set(l, o.offset(x, y, z), log);
            }
        }
        for (int i = 0; i < 6; i++) {
            double a = Math.PI * 2 * i / 6 + 0.5;
            int by = 30 + (i % 3) * 5;
            for (int t = 3; t <= 13; t++) {
                int x = (int) Math.round(Math.cos(a) * t), z = (int) Math.round(Math.sin(a) * t);
                int y = by + (int) (t * 0.4);
                set(l, o.offset(x, y, z), log);
                set(l, o.offset(x, y + 1, z), log);
            }
        }
        sphere(l, o, 0, h - 6, 0, 11);
        for (int i = 0; i < 6; i++) {
            double a = Math.PI * 2 * i / 6;
            sphere(l, o, (int) Math.round(Math.cos(a) * 7), h - 14 + (i % 2) * 6, (int) Math.round(Math.sin(a) * 7), 8);
        }
    }

    static BlockState statue(String id) { return Reg.B.get(id).get().defaultBlockState(); }

    // ------------------------------------------------------------------ estatuas de los 7 pecados y Hawk
    public static class SinStatues extends Feature<NoneFeatureConfiguration> {
        public SinStatues() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 7, 3)) return false;
            platform(l, o, 7, s(Blocks.STONE_BRICKS));
            String[] ids = {"meliodas", "diane", "ban", "king", "gowther", "merlin", "escanor"};
            for (int i = 0; i < 7; i++) {
                double a = Math.PI * 2 * i / 7;
                BlockPos q = o.offset((int) Math.round(Math.cos(a) * 5), 0, (int) Math.round(Math.sin(a) * 5));
                set(l, q, statue("estatua_" + ids[i]));
                set(l, q.below(), s(Blocks.POLISHED_ANDESITE));
                BlockPos lp = o.offset((int) Math.round(Math.cos(a) * 6.5), 0, (int) Math.round(Math.sin(a) * 6.5));
                set(l, lp, s(Blocks.STONE_BRICK_WALL));
                set(l, lp.above(), s(Blocks.LANTERN));
            }
            box(l, o, -1, -1, -1, 1, -1, 1, s(Blocks.GOLD_BLOCK));
            set(l, o, statue("estatua_hawk"));
            spawn(l, Reg.HAWK.get(), o.getX() + 2.5, o.getY(), o.getZ() + 0.5);
            String[] who = {"diane", "ban", "king", "gowther", "merlin"};
            npc(l, who[l.getRandom().nextInt(who.length)], o.getX() + 0.5, o.getY() + 1, o.getZ() + 2.5);
            return true;
        }
    }

    // ------------------------------------------------------------------ santuario de un arcangel (da una Gracia)
    public static class Archangel extends Feature<NoneFeatureConfiguration> {
        public Archangel() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 4, 3)) return false;
            platform(l, o, 4, s(Blocks.QUARTZ_BLOCK));
            String[] ids = {"sol", "brillo", "oceano", "viento"};
            set(l, o, statue("arcangel_" + ids[l.getRandom().nextInt(4)]));
            set(l, o.below(), s(Blocks.CHISELED_QUARTZ_BLOCK));
            int[][] corners = {{-3, -3}, {3, -3}, {-3, 3}, {3, 3}};
            for (int[] q : corners) {
                box(l, o, q[0], 0, q[1], q[0], 3, q[1], s(Blocks.QUARTZ_PILLAR));
                set(l, o.offset(q[0], 4, q[1]), s(Blocks.SEA_LANTERN));
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ Excalibur en la piedra
    public static class ExcaliburStone extends Feature<NoneFeatureConfiguration> {
        public ExcaliburStone() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 4, 2)) return false;
            platform(l, o, 4, s(Blocks.MOSS_BLOCK));
            set(l, o.below(), s(Blocks.MOSSY_COBBLESTONE));
            set(l, o, statue("piedra_excalibur"));
            int[][] st = {{-3, 0}, {3, 0}, {0, -3}, {0, 3}};
            for (int[] q : st) {
                box(l, o, q[0], 0, q[1], q[0], 2, q[1], s(Blocks.COBBLESTONE_WALL));
                set(l, o.offset(q[0], 3, q[1]), s(Blocks.LANTERN));
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ santuario de tesoro sagrado
    public static class TreasureShrine extends Feature<NoneFeatureConfiguration> {
        public TreasureShrine() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 3, 2)) return false;
            platform(l, o, 3, s(Blocks.DEEPSLATE_BRICKS));
            chest(l, o, "treasure_shrine");
            int[][] corners = {{-2, -2}, {2, -2}, {-2, 2}, {2, 2}};
            for (int[] q : corners) {
                box(l, o, q[0], 0, q[1], q[0], 2, q[1], s(Blocks.POLISHED_DEEPSLATE));
                set(l, o.offset(q[0], 3, q[1]), s(Blocks.SOUL_LANTERN));
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ ciudad de Liones: castillo + taberna de Escanor
    public static class Liones extends Feature<NoneFeatureConfiguration> {
        public Liones() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 6, 3)) return false;
            BlockState sb = s(Blocks.STONE_BRICKS);
            // terreno plano y despejado: castillo (-6..6) y taberna (7..15)
            pad(l, o, -6, -6, 6, 6, s(Blocks.POLISHED_ANDESITE));
            air(l, o, -6, 0, -6, 6, 12, 6);
            // muralla
            for (int i = -6; i <= 6; i++) {
                for (int y = 0; y <= 5; y++) {
                    set(l, o.offset(i, y, -6), sb);
                    set(l, o.offset(i, y, 6), sb);
                    set(l, o.offset(-6, y, i), sb);
                    set(l, o.offset(6, y, i), sb);
                }
                if (i % 2 == 0) {
                    set(l, o.offset(i, 6, -6), sb);
                    set(l, o.offset(i, 6, 6), sb);
                    set(l, o.offset(-6, 6, i), sb);
                    set(l, o.offset(6, 6, i), sb);
                }
            }
            // torres en las esquinas
            int[][] cs = {{-6, -6}, {6, -6}, {-6, 6}, {6, 6}};
            for (int[] q : cs) {
                for (int x = -1; x <= 1; x++)
                    for (int z = -1; z <= 1; z++) {
                        for (int y = 0; y <= 8; y++) {
                            boolean edge = Math.abs(x) == 1 || Math.abs(z) == 1;
                            set(l, o.offset(q[0] + x, y, q[1] + z), edge ? sb : s(Blocks.AIR));
                        }
                        if ((x + z) % 2 == 0) set(l, o.offset(q[0] + x, 9, q[1] + z), sb);
                    }
                set(l, o.offset(q[0], 10, q[1]), s(Blocks.LANTERN));
            }
            // puerta sur (z = +6)
            air(l, o, -1, 0, 6, 1, 3, 6);
            // torre del homenaje 5x5
            for (int x = -2; x <= 2; x++)
                for (int z = -2; z <= 2; z++) {
                    boolean edge = Math.abs(x) == 2 || Math.abs(z) == 2;
                    for (int y = 0; y <= 7; y++) set(l, o.offset(x, y, z), edge ? s(Blocks.STONE_BRICKS) : s(Blocks.AIR));
                    set(l, o.offset(x, 8, z), s(Blocks.BLUE_WOOL));
                }
            air(l, o, 0, 0, 2, 0, 1, 2);
            chest(l, o.offset(0, 0, -1), "liones");
            set(l, o.offset(1, 0, -1), s(Blocks.LANTERN));
            // taberna 9x9 centrada en x=11
            BlockPos t = o.offset(11, 0, 0);
            pad(l, t, -4, -4, 4, 4, s(Blocks.OAK_PLANKS));
            air(l, t, -4, 0, -4, 4, 8, 4);
            for (int x = -4; x <= 4; x++)
                for (int z = -4; z <= 4; z++) {
                    boolean wall = Math.abs(x) == 4 || Math.abs(z) == 4;
                    boolean corner = Math.abs(x) == 4 && Math.abs(z) == 4;
                    for (int y = 0; y <= 3; y++) {
                        if (corner) set(l, t.offset(x, y, z), s(Blocks.STRIPPED_SPRUCE_LOG));
                        else if (wall) set(l, t.offset(x, y, z), s(Blocks.SPRUCE_PLANKS));
                    }
                    set(l, t.offset(x, 4, z), s(Blocks.SPRUCE_SLAB));
                }
            air(l, t, -4, 0, 0, -4, 1, 0);
            box(l, t, 1, 0, 1, 3, 0, 1, s(Blocks.SPRUCE_SLAB));
            box(l, t, 3, 0, -3, 3, 0, -1, s(Blocks.BARREL));
            set(l, t.offset(-3, 0, 3), s(Blocks.BARREL));
            set(l, t.offset(-3, 0, -3), s(Blocks.BARREL));
            set(l, t.offset(-2, 0, 2), s(Blocks.OAK_FENCE));
            set(l, t.offset(-2, 1, 2), s(Blocks.OAK_PRESSURE_PLATE));
            set(l, t.offset(0, 0, -2), s(Blocks.OAK_FENCE));
            set(l, t.offset(0, 1, -2), s(Blocks.OAK_PRESSURE_PLATE));
            set(l, t.offset(-3, 0, 0), s(Blocks.LANTERN));
            set(l, t.offset(2, 0, 3), s(Blocks.LANTERN));
            // habitantes
            spawn(l, Reg.ESCANOR.get(), t.getX() + 2.5, t.getY(), t.getZ() + 0.5);
            spawn(l, Reg.HAWK.get(), t.getX() - 1.5, t.getY(), t.getZ() + 2.5);
            for (int i = 0; i < 3; i++) spawn(l, Reg.KNIGHT.get(), o.getX() - 1.5 + i * 1.5, o.getY(), o.getZ() + 8.5);
            return true;
        }
    }

    // ------------------------------------------------------------------ bosque del Rey Hada
    public static class FairyForest extends Feature<NoneFeatureConfiguration> {
        public FairyForest() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 8, 6)) return false;
            // musgo en el suelo
            for (int x = -13; x <= 13; x++)
                for (int z = -13; z <= 13; z++) {
                    if (x * x + z * z > 169) continue;
                    int h = l.getHeight(Heightmap.Types.WORLD_SURFACE_WG, o.getX() + x, o.getZ() + z);
                    BlockPos g = new BlockPos(o.getX() + x, h - 1, o.getZ() + z);
                    if (l.getFluidState(g).isEmpty() && l.getBlockState(g).isSolid()) {
                        set(l, g, s(Blocks.MOSS_BLOCK));
                        if (l.getRandom().nextInt(4) == 0) set(l, g.above(), s(Blocks.PINK_PETALS));
                        else if (l.getRandom().nextInt(6) == 0) set(l, g.above(), s(Blocks.MOSS_CARPET));
                    }
                }
            // arboles luminosos
            for (int i = 0; i < 14; i++) {
                int x = l.getRandom().nextInt(25) - 12, z = l.getRandom().nextInt(25) - 12;
                if (x * x + z * z < 100) continue;
                if (x * x + z * z > 169) continue;
                int h = l.getHeight(Heightmap.Types.WORLD_SURFACE_WG, o.getX() + x, o.getZ() + z);
                BlockPos b = new BlockPos(o.getX() + x, h, o.getZ() + z);
                int th = 6 + l.getRandom().nextInt(4);
                for (int y = 0; y < th; y++) set(l, b.above(y), s(Blocks.CHERRY_LOG));
                for (int dx = -3; dx <= 3; dx++)
                    for (int dy = -2; dy <= 2; dy++)
                        for (int dz = -3; dz <= 3; dz++) {
                            if (dx * dx + dy * dy * 2 + dz * dz > 11) continue;
                            BlockPos lp = b.offset(dx, th - 1 + dy, dz);
                            if (l.getBlockState(lp).isAir()) set(l, lp, leaf(Blocks.CHERRY_LEAVES));
                        }
                set(l, b.offset(1, th - 2, 0), s(Blocks.SHROOMLIGHT));
                set(l, b.offset(-1, th - 3, 1), s(Blocks.SHROOMLIGHT));
            }
            // Gran Arbol Sagrado con la camara del Rey Hada
            sacredTree(l, o);
            set(l, o.offset(0, 1, -2), s(Blocks.QUARTZ_STAIRS));
            chest(l, o.offset(2, 1, -1), "fairy");
            Fairy king = Reg.FAIRY.get().create(l.getLevel());
            if (king != null) {
                king.moveTo(o.getX() + 0.5, o.getY() + 2, o.getZ() + 0.5, 0f, 0f);
                king.finalizeSpawn(l, l.getCurrentDifficultyAt(o), MobSpawnType.STRUCTURE, null, null);
                king.makeKing();
                l.addFreshEntity(king);
            }
            for (int i = 0; i < 8; i++) {
                double an = l.getRandom().nextDouble() * Math.PI * 2, dd = 8 + l.getRandom().nextInt(5);
                spawn(l, Reg.FAIRY.get(), o.getX() + 0.5 + Math.cos(an) * dd, o.getY() + 3 + l.getRandom().nextInt(4), o.getZ() + 0.5 + Math.sin(an) * dd);
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ Taberna del Sombrero del Jabali (Boar Hat)
    public static class BoarHat extends Feature<NoneFeatureConfiguration> {
        public BoarHat() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 6, 3)) return false;
            pad(l, o, -6, -5, 6, 5, s(Blocks.OAK_PLANKS));
            air(l, o, -6, 0, -5, 6, 16, 5);
            for (int x = -6; x <= 6; x++)
                for (int z = -5; z <= 5; z++) {
                    boolean wall = Math.abs(x) == 6 || Math.abs(z) == 5;
                    boolean corner = Math.abs(x) == 6 && Math.abs(z) == 5;
                    for (int y = 0; y <= 4; y++) {
                        if (corner) set(l, o.offset(x, y, z), s(Blocks.STRIPPED_SPRUCE_LOG));
                        else if (wall) set(l, o.offset(x, y, z), s(Blocks.SPRUCE_PLANKS));
                    }
                    set(l, o.offset(x, 5, z), s(Blocks.SPRUCE_SLAB));
                }
            air(l, o, 0, 0, 5, 1, 1, 5);
            for (int x : new int[]{-3, 3}) {
                set(l, o.offset(x, 1, -5), s(Blocks.GLASS_PANE));
                set(l, o.offset(x, 2, -5), s(Blocks.GLASS_PANE));
                set(l, o.offset(x, 1, 5), s(Blocks.GLASS_PANE));
                set(l, o.offset(x, 2, 5), s(Blocks.GLASS_PANE));
            }
            // barra, barriles y mesas
            box(l, o, -4, 0, -1, 4, 0, -1, s(Blocks.SPRUCE_SLAB));
            for (int x = -4; x <= 4; x += 2) set(l, o.offset(x, 0, -4), s(Blocks.BARREL));
            set(l, o.offset(-4, 0, 3), s(Blocks.OAK_FENCE));
            set(l, o.offset(-4, 1, 3), s(Blocks.OAK_PRESSURE_PLATE));
            set(l, o.offset(4, 0, 3), s(Blocks.OAK_FENCE));
            set(l, o.offset(4, 1, 3), s(Blocks.OAK_PRESSURE_PLATE));
            for (int x : new int[]{-5, 5}) set(l, o.offset(x, 0, 0), s(Blocks.LANTERN));
            chest(l, o.offset(5, 0, -4), "liones");
            // gran cabeza de jabali rosa sobre el techo
            BlockState wool = s(Blocks.PINK_WOOL), snout = s(Blocks.PINK_CONCRETE), blk = s(Blocks.BLACK_CONCRETE);
            box(l, o, -3, 6, -2, 3, 10, 2, wool);
            box(l, o, -1, 7, 3, 1, 8, 4, snout);
            set(l, o.offset(-1, 8, 4), blk);
            set(l, o.offset(1, 8, 4), blk);
            set(l, o.offset(-2, 9, 3), blk);
            set(l, o.offset(2, 9, 3), blk);
            set(l, o.offset(-2, 7, 3), s(Blocks.WHITE_CONCRETE));
            set(l, o.offset(2, 7, 3), s(Blocks.WHITE_CONCRETE));
            box(l, o, -3, 11, -1, -3, 11, 0, s(Blocks.PINK_TERRACOTTA));
            box(l, o, 3, 11, -1, 3, 11, 0, s(Blocks.PINK_TERRACOTTA));
            // habitantes
            npc(l, "meliodas", o.getX() + 0.5, o.getY(), o.getZ() - 1.5);
            npc(l, "elizabeth", o.getX() + 2.5, o.getY(), o.getZ() + 1.5);
            spawn(l, Reg.HAWK.get(), o.getX() - 2.5, o.getY(), o.getZ() + 2.5);
            return true;
        }
    }
}
