package com.nanatsu.chaos;

import java.util.ArrayDeque;
import javax.annotation.Nullable;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Los 7 Tesoros Sagrados. */
public final class Treasures {
    private Treasures() {}

    public static void rewind(ServerPlayer p) {
        ArrayDeque<double[]> q = Powers.HIST.get(p.getUUID());
        if (q == null || q.isEmpty()) return;
        double[] s = q.peekFirst();
        p.teleportTo(s[0], s[1], s[2]);
        p.setHealth(Math.max(p.getHealth(), (float) s[3]));
        p.fallDistance = 0;
    }

    public static boolean hasCourechouse(Player p) {
        for (ItemStack s : p.getInventory().items) {
            if (s.getItem() instanceof Courechouse) return true;
        }
        return false;
    }

    // Meliodas: absorbe dano infinito y lo devuelve. Shift+clic: ilusiones.
    public static class Lostvayne extends SwordItem {
        public Lostvayne() { super(Gifts.TIER, 14, -2.2f, Gifts.rare()); }

        @Override public int getUseDuration(ItemStack s) { return 72000; }
        @Override public UseAnim getUseAnimation(ItemStack s) { return UseAnim.BLOCK; }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (p.isShiftKeyDown()) {
                if (!l.isClientSide && p instanceof ServerPlayer sp && Powers.ready(sp, "lostvayne_clones", 300)) {
                    for (int i = 0; i < 3; i++) {
                        IllusionClone c = Reg.CLONE.get().create(l);
                        if (c == null) continue;
                        c.setOwner(sp);
                        c.moveTo(sp.getX() + Powers.rnd(sp, 2), sp.getY(), sp.getZ() + Powers.rnd(sp, 2));
                        l.addFreshEntity(c);
                    }
                    Powers.msg(sp, "Ilusiones de ti mismo");
                }
                return InteractionResultHolder.sidedSuccess(s, l.isClientSide);
            }
            p.startUsingItem(h);
            return InteractionResultHolder.consume(s);
        }

        @Override
        public void onUseTick(Level l, LivingEntity e, ItemStack s, int left) {
            if (!l.isClientSide && e instanceof ServerPlayer p && left % 10 == 0) {
                CompoundTag t = s.getOrCreateTag();
                Powers.msg(p, "Dano absorbido: " + (long) t.getDouble("stored") + "  (cargas: " + (int) (t.getDouble("stored") / 100) + ")");
            }
        }

        @Override
        public void releaseUsing(ItemStack s, Level l, LivingEntity e, int left) {
            if (l.isClientSide || !(e instanceof ServerPlayer sp)) return;
            CompoundTag t = s.getOrCreateTag();
            double stored = t.getDouble("stored");
            if (stored <= 0) return;
            t.putDouble("stored", 0);
            int charges = (int) (stored / 100);
            ServerLevel lv = sp.serverLevel();
            Vec3 tgt = Powers.aim(sp, 70);
            double rad = 5 + Math.min(charges, 60) * 0.6;
            sp.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 4));
            for (LivingEntity v : lv.getEntitiesOfClass(LivingEntity.class, new AABB(tgt, tgt).inflate(rad),
                    x -> x != sp && x.isAlive() && Powers.ok(sp, x))) {
                v.invulnerableTime = 0;
                v.hurt(sp.damageSources().playerAttack(sp), (float) Math.min(stored, 1.0E9));
            }
            if (charges == 0) {
                lv.explode(null, tgt.x, tgt.y, tgt.z, 1.5f, Level.ExplosionInteraction.NONE);
            } else {
                lv.explode(null, tgt.x, tgt.y, tgt.z, Math.min(2 + charges * 0.5f, 25f), Level.ExplosionInteraction.TNT);
                int n = Math.min(charges, 40);
                for (int i = 0; i < n; i++) {
                    double a = lv.random.nextDouble() * Math.PI * 2, r = lv.random.nextDouble() * rad;
                    lv.explode(null, tgt.x + Math.cos(a) * r, tgt.y, tgt.z + Math.sin(a) * r,
                            3f + Math.min(i, 20) * 0.25f, Level.ExplosionInteraction.TNT);
                }
                if (charges >= 5) for (int i = 0; i < Math.min(charges / 2, 12); i++) {
                    Powers.bolt(sp, tgt.add(Powers.rnd(sp, rad), 0, Powers.rnd(sp, rad)));
                }
                if (charges >= 15) for (int i = 0; i < Math.min(charges / 5, 10); i++) {
                    Powers.fire(sp, tgt.x + Powers.rnd(sp, rad), tgt.y + 30 + i * 2, tgt.z + Powers.rnd(sp, rad), 4);
                }
            }
            Powers.msg(sp, "§c¡Contraataque de " + (long) stored + " de dano!");
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, java.util.List<Component> t, net.minecraft.world.item.TooltipFlag f) {
            Gifts.tip(t, "Manten clic derecho: absorbe todo el dano (sin limite).");
            Gifts.tip(t, "Suelta: contraataque. Cada 100 de dano = un efecto destructivo mayor.");
            Gifts.tip(t, "Shift + clic derecho: crea ilusiones tuyas que atacan.");
        }
    }

    // Escanor: hacha del Sol. Mucho mas fuerte de dia.
    public static class Rhitta extends AxeItem {
        public Rhitta() { super(Gifts.TIER, 20, -3.0f, Gifts.rare()); }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            if (!l.isClientSide && p instanceof ServerPlayer sp && Powers.ready(sp, "rhitta", 400)) {
                boolean sun = l.isDay() && l.canSeeSky(sp.blockPosition());
                for (LivingEntity e : Powers.n(sp, 12)) {
                    Powers.melee(sp, e, sun ? 180 : 60);
                    e.setSecondsOnFire(10);
                }
                Powers.sp(sp, ParticleTypes.FLAME, sp.getX(), sp.getY() + 1, sp.getZ(), 200, 5, 0.2);
            }
            return InteractionResultHolder.sidedSuccess(p.getItemInHand(h), l.isClientSide);
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, java.util.List<Component> t, net.minecraft.world.item.TooltipFlag f) {
            Gifts.tip(t, "Bajo el sol su dano se multiplica x3.5. Clic derecho: estallido solar.");
        }
    }

    // Merlin: bastón. Teletransporte e Infinity (retroceder en el tiempo).
    public static class Courechouse extends Item {
        public Courechouse() { super(Gifts.rare()); }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                if (sp.isShiftKeyDown()) {
                    if (Powers.ready(sp, "rewind", 600)) {
                        rewind(sp);
                        Powers.msg(sp, "Infinity: el tiempo retrocede 10 segundos");
                    }
                } else if (Powers.ready(sp, "merlin_tp", 60)) {
                    Vec3 t = Powers.aim(sp, 60).subtract(sp.getLookAngle().scale(0.6));
                    sp.teleportTo(t.x, t.y, t.z);
                }
            }
            return InteractionResultHolder.sidedSuccess(p.getItemInHand(h), l.isClientSide);
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, java.util.List<Component> t, net.minecraft.world.item.TooltipFlag f) {
            Gifts.tip(t, "Clic derecho: teletransporte. Shift: retrocede 10s en el tiempo.");
            Gifts.tip(t, "En el inventario: evita una muerte cada 2 minutos.");
        }
    }

    // Gowther: control mental.
    public static class Herrit extends SwordItem {
        public Herrit() { super(Gifts.TIER, 10, -2.0f, Gifts.rare()); }

        static void charm(ServerPlayer p, double r) {
            for (LivingEntity e : Powers.n(p, r)) {
                if (e instanceof Mob m) m.getPersistentData().putInt("nc_charm", 300);
            }
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            if (!l.isClientSide && p instanceof ServerPlayer sp && Powers.ready(sp, "herrit", 300)) {
                charm(sp, 14);
                Powers.msg(sp, "Los enemigos pierden la razon");
            }
            return InteractionResultHolder.sidedSuccess(p.getItemInHand(h), l.isClientSide);
        }

        @Override
        public InteractionResult interactLivingEntity(ItemStack s, Player p, LivingEntity t, InteractionHand h) {
            if (!p.level().isClientSide && t instanceof Mob m && t instanceof Enemy) {
                m.getPersistentData().putInt("nc_charm", 600);
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, java.util.List<Component> t, net.minecraft.world.item.TooltipFlag f) {
            Gifts.tip(t, "Clic derecho: los enemigos cercanos se atacan entre si.");
            Gifts.tip(t, "Clic derecho sobre un enemigo: lo controlas 30s.");
        }
    }

    // Ban: roba vida.
    public static class Aldan extends SwordItem {
        public Aldan() { super(Gifts.TIER, 12, -2.2f, Gifts.rare()); }

        @Override
        public boolean hurtEnemy(ItemStack s, LivingEntity t, LivingEntity a) {
            a.heal(4);
            return super.hurtEnemy(s, t, a);
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            if (!l.isClientSide && p instanceof ServerPlayer sp && Powers.ready(sp, "aldan", 150)) {
                float heal = 0;
                for (LivingEntity e : Powers.n(sp, 7)) {
                    Powers.melee(sp, e, 25);
                    heal += 10;
                }
                sp.heal(Math.min(heal, 20));
                Powers.sp(sp, ParticleTypes.SWEEP_ATTACK, sp.getX(), sp.getY() + 1, sp.getZ(), 12, 3, 0);
            }
            return InteractionResultHolder.sidedSuccess(p.getItemInHand(h), l.isClientSide);
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, java.util.List<Component> t, net.minecraft.world.item.TooltipFlag f) {
            Gifts.tip(t, "Roba vida al golpear. Clic derecho: Hunter Fest.");
        }
    }

    // King: lanza espiritual.
    public static class Chastiefol extends SwordItem {
        public Chastiefol() { super(Gifts.TIER, 11, -2.0f, Gifts.rare()); }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            if (!l.isClientSide && p instanceof ServerPlayer sp && Powers.ready(sp, "chastiefol", 100)) {
                for (int i = -1; i <= 1; i++) {
                    Powers.ray(sp, sp.getLookAngle().yRot((float) Math.toRadians(i * 6)), 45, 1.3, 35, ParticleTypes.END_ROD, false, false);
                }
            }
            return InteractionResultHolder.sidedSuccess(p.getItemInHand(h), l.isClientSide);
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, java.util.List<Component> t, net.minecraft.world.item.TooltipFlag f) {
            Gifts.tip(t, "Clic derecho: lanzas espirituales de largo alcance.");
        }
    }

    // Diane: martillo de gigante.
    public static class Gideon extends AxeItem {
        public Gideon() { super(Gifts.TIER, 22, -3.2f, Gifts.rare()); }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            if (!l.isClientSide && p instanceof ServerPlayer sp && Powers.ready(sp, "gideon", 200)) {
                for (LivingEntity e : Powers.n(sp, 9)) {
                    Powers.melee(sp, e, 35);
                    Powers.push(sp, e, 1.2, 0.8);
                }
                Powers.sp(sp, ParticleTypes.EXPLOSION, sp.getX(), sp.getY() + 0.2, sp.getZ(), 10, 3, 0);
                Powers.boom(sp);
            }
            return InteractionResultHolder.sidedSuccess(p.getItemInHand(h), l.isClientSide);
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, java.util.List<Component> t, net.minecraft.world.item.TooltipFlag f) {
            Gifts.tip(t, "Clic derecho: martillazo que sacude el suelo.");
        }
    }
}
