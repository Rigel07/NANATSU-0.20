package com.nanatsu.chaos.client;

import com.nanatsu.chaos.NanatsuChaos;
import com.nanatsu.chaos.Hawk;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo propio generado a mano (sin moldes de vanilla). */
public class HawkModel extends EntityModel<Hawk> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(NanatsuChaos.MODID, "hawk"), "main");
    private final ModelPart root;
    public final ModelPart body;
    public final ModelPart head;
    public final ModelPart snout;
    public final ModelPart earL;
    public final ModelPart earR;
    public final ModelPart legFR;
    public final ModelPart legFL;
    public final ModelPart legBR;
    public final ModelPart legBL;
    public final ModelPart tail;
    public final ModelPart tail2;

    public HawkModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.snout = this.head.getChild("snout");
        this.earL = this.head.getChild("earL");
        this.earR = this.head.getChild("earR");
        this.legFR = root.getChild("legFR");
        this.legFL = root.getChild("legFL");
        this.legBR = root.getChild("legBR");
        this.legBL = root.getChild("legBL");
        this.tail = root.getChild("tail");
        this.tail2 = this.tail.getChild("tail2");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition p_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, -5.0F, -7.0F, 12.0F, 10.0F, 14.0F), PartPose.offsetAndRotation(0.0F, 14.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 24).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 7.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 13.0F, -6.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_snout = p_head.addOrReplaceChild("snout", CubeListBuilder.create().texOffs(28, 24).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 4.0F, 3.0F), PartPose.offsetAndRotation(0.0F, 0.5F, -5.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_earL = p_head.addOrReplaceChild("earL", CubeListBuilder.create().texOffs(46, 24).addBox(0.0F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.5F, -3.5F, -1.0F, 0.0F, 0.0F, 0.9F));
        PartDefinition p_earR = p_head.addOrReplaceChild("earR", CubeListBuilder.create().texOffs(0, 37).addBox(-3.0F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-3.5F, -3.5F, -1.0F, 0.0F, 0.0F, -0.9F));
        PartDefinition p_legFR = r.addOrReplaceChild("legFR", CubeListBuilder.create().texOffs(14, 37).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 5.0F, 3.0F), PartPose.offsetAndRotation(-3.5F, 19.0F, -4.5F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_legFL = r.addOrReplaceChild("legFL", CubeListBuilder.create().texOffs(26, 37).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 5.0F, 3.0F), PartPose.offsetAndRotation(3.5F, 19.0F, -4.5F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_legBR = r.addOrReplaceChild("legBR", CubeListBuilder.create().texOffs(38, 37).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 5.0F, 3.0F), PartPose.offsetAndRotation(-3.5F, 19.0F, 4.5F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_legBL = r.addOrReplaceChild("legBL", CubeListBuilder.create().texOffs(50, 37).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 5.0F, 3.0F), PartPose.offsetAndRotation(3.5F, 19.0F, 4.5F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_tail = r.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(0, 45).addBox(-0.5F, -0.5F, 0.0F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, 11.0F, 7.0F, -0.6F, 0.0F, 0.0F));
        PartDefinition p_tail2 = p_tail.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(8, 45).addBox(-0.5F, -0.5F, 0.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 3.0F, 0.9F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(Hawk e, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * 0.017453292F;
        this.head.xRot = headPitch * 0.017453292F;
        float s = Mth.cos(limbSwing * 0.8F) * 1.3F * limbSwingAmount;
        this.legFR.xRot = s; this.legBL.xRot = s; this.legFL.xRot = -s; this.legBR.xRot = -s;
        this.tail.zRot = Mth.cos(ageInTicks * 0.4F) * 0.35F;
        this.earL.zRot = 0.9F + Mth.cos(ageInTicks * 0.1F) * 0.06F;
        this.earR.zRot = -0.9F - Mth.cos(ageInTicks * 0.1F) * 0.06F;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
