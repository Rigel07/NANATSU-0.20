package com.nanatsu.chaos.client;

import com.nanatsu.chaos.Net;
import com.nanatsu.chaos.Race;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

/** Menu de eleccion de raza: aparece solo al entrar, sin comandos ni teclas. */
public class RaceScreen extends Screen {
    static final Race[] R = {Race.HUMANO, Race.GIGANTE, Race.DEMONIO, Race.HADA, Race.DIOSA};
    int cw, ch, x0, y0;

    public RaceScreen() {
        super(Component.literal("Elige tu raza"));
    }

    @Override
    protected void init() {
        cw = Math.min(150, (width - 40) / 5 - 8);
        ch = Math.min(height - 90, 210);
        x0 = (width - (cw * 5 + 8 * 4)) / 2;
        y0 = (height - ch) / 2 + 16;
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }

    private int hover(double mx, double my) {
        if (my < y0 || my > y0 + ch) return -1;
        for (int i = 0; i < 5; i++) {
            int x = x0 + i * (cw + 8);
            if (mx >= x && mx <= x + cw) return i;
        }
        return -1;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(0, 0, width, height, 0xF0080414, 0xF02A0B3A);
        g.pose().pushPose();
        g.pose().translate(width / 2f, y0 - 44, 0);
        g.pose().scale(2.2f, 2.2f, 1f);
        g.drawCenteredString(font, "Elige tu destino", 0, 0, 0xFFD27A);
        g.pose().popPose();
        g.drawCenteredString(font, "Tu raza define tus poderes en el mundo de los Siete Pecados Capitales", width / 2, y0 - 22, 0xB9A8D8);
        int hv = hover(mx, my);
        for (int i = 0; i < 5; i++) {
            Race r = R[i];
            int x = x0 + i * (cw + 8);
            boolean h = i == hv;
            int col = 0xFF000000 | r.color;
            g.fill(x - 1, y0 - 1, x + cw + 1, y0 + ch + 1, h ? 0xFFFFFFFF : col);
            g.fill(x, y0, x + cw, y0 + ch, h ? 0xF0382058 : 0xE0160B24);
            g.fill(x, y0, x + cw, y0 + 24, col);
            g.drawCenteredString(font, r.label, x + cw / 2, y0 + 8, 0x101010);
            int yy = y0 + 32;
            for (String line : r.lines) {
                List<FormattedCharSequence> seq = font.split(Component.literal(line), cw - 10);
                for (FormattedCharSequence s : seq) {
                    g.drawString(font, s, x + 5, yy, 0xDDDDDD, false);
                    yy += 10;
                }
                yy += 5;
            }
            g.drawCenteredString(font, h ? "§e¡Clic para elegir!" : "§7Clic para elegir", x + cw / 2, y0 + ch - 14, 0xFFFFFF);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        int i = hover(mx, my);
        if (i >= 0 && btn == 0) {
            Net.CH.sendToServer(new Net.Choose(R[i].ordinal()));
            Minecraft.getInstance().setScreen(null);
            return true;
        }
        return super.mouseClicked(mx, my, btn);
    }
}
