package com.nanatsu.chaos.client;

import com.nanatsu.chaos.IllusionClone;
import com.nanatsu.chaos.NanatsuChaos;
import com.nanatsu.chaos.Reg;
import java.util.UUID;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = NanatsuChaos.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    public static final KeyMapping USE = new KeyMapping("key.nanatsuchaos.use", GLFW.GLFW_KEY_R, "key.categories.nanatsuchaos");
    public static final KeyMapping NEXT = new KeyMapping("key.nanatsuchaos.next", GLFW.GLFW_KEY_V, "key.categories.nanatsuchaos");
    public static final KeyMapping MENU = new KeyMapping("key.nanatsuchaos.menu", GLFW.GLFW_KEY_J, "key.categories.nanatsuchaos");

    static ResourceLocation tex(String n) { return new ResourceLocation(NanatsuChaos.MODID, "textures/entity/" + n + ".png"); }

    static ResourceLocation skin(IllusionClone c) {
        UUID u = c.getOwnerId().orElse(c.getUUID());
        ClientPacketListener con = Minecraft.getInstance().getConnection();
        if (con != null) {
            PlayerInfo i = con.getPlayerInfo(u);
            if (i != null) return i.getSkinLocation();
        }
        return DefaultPlayerSkin.getDefaultSkin(u);
    }

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) {
        e.register(USE);
        e.register(NEXT);
        e.register(MENU);
    }

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(HawkModel.LAYER, HawkModel::createBodyLayer);
        e.registerLayerDefinition(CathKittenModel.LAYER, CathKittenModel::createBodyLayer);
        e.registerLayerDefinition(CathBossModel.LAYER, CathBossModel::createBodyLayer);
        e.registerLayerDefinition(FairyModel.LAYER, FairyModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(Reg.HAWK.get(), HawkRenderer::new);
        e.registerEntityRenderer(Reg.CATH.get(), CathRenderer::new);
        e.registerEntityRenderer(Reg.FAIRY.get(), FairyRenderer::new);
        e.registerEntityRenderer(Reg.SIN_NPC.get(), c -> new HumanRenderer<>(c, n -> tex("npc_" + n.getWho()), n -> 1.0f, false));
        e.registerEntityRenderer(Reg.KNIGHT.get(), c -> new HumanRenderer<>(c, k -> tex("holy_knight"), k -> 1.0f, true));
        e.registerEntityRenderer(Reg.ESCANOR.get(), c -> new HumanRenderer<>(c, k -> tex("escanor"), k -> 1.35f, false));
        e.registerEntityRenderer(Reg.CLONE.get(), c -> new HumanRenderer<>(c, ClientSetup::skin, k -> 1.0f, false));
    }
}
