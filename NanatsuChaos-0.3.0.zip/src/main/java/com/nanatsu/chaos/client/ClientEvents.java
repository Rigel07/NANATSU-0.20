package com.nanatsu.chaos.client;

import com.nanatsu.chaos.NanatsuChaos;
import com.nanatsu.chaos.Net;
import com.nanatsu.chaos.Powers;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = NanatsuChaos.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientEvents {
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        while (ClientSetup.MENU.consumeClick()) {
            if (mc.screen == null && !ClientData.race.equals("NONE")) mc.setScreen(new PowersScreen());
        }
        if (mc.screen != null) return;
        while (ClientSetup.USE.consumeClick()) Net.CH.sendToServer(new Net.Action(0, 0));
        while (ClientSetup.NEXT.consumeClick()) Net.CH.sendToServer(new Net.Action(1, 0));
    }

    @SubscribeEvent
    public static void hud(RenderGuiOverlayEvent.Post e) {
        if (e.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;
        if (ClientData.race.equals("NONE") || ClientData.av.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) return;
        int sel = Math.floorMod(ClientData.sel, ClientData.av.size());
        Powers.Ability a = Powers.ALL.get(ClientData.av.get(sel));
        if (a == null) return;
        long left = (ClientData.cdEnd - System.currentTimeMillis()) / 1000 + 1;
        String st = left > 0 && ClientData.cdEnd > System.currentTimeMillis() ? "§c" + left + "s" : "§aLista";
        GuiGraphics g = e.getGuiGraphics();
        int y = e.getWindow().getGuiScaledHeight() - 42;
        g.drawString(mc.font, "§d[R] §f" + a.name() + " §7(" + (sel + 1) + "/" + ClientData.av.size() + ") " + st, 8, y, 0xFFFFFF);
        g.drawString(mc.font, "§8[V] cambiar  [J] menu", 8, y + 10, 0xFFFFFF);
    }
}
