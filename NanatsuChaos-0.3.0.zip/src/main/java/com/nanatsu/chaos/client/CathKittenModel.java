package com.nanatsu.chaos.client;

import com.nanatsu.chaos.NanatsuChaos;
import com.nanatsu.chaos.CathPalug;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo propio generado a mano (sin moldes de vanilla). */
public class CathKittenModel extends EntityModel<CathPalug> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(NanatsuChaos.MODID, "cath_kitten"), "main");
    private final ModelPart root;
    public final ModelPart body;
    public final ModelPart head;
    public final ModelPart earL;
    public final ModelPart earR;
    public final ModelPart pawFL;
    public final ModelPart pawFR;
    public final ModelPart pawBL;
    public final ModelPart pawBR;
    public final ModelPart tail;
    public final ModelPart tail2;

    public CathKittenModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.earL = this.head.getChild("earL");
        this.earR = this.head.getChild("earR");
        this.pawFL = root.getChild("pawFL");
        this.pawFR = root.getChild("pawFR");
        this.pawBL = root.getChild("pawBL");
        this.pawBR = root.getChild("pawBR");
        this.tail = root.getChild("tail");
        this.tail2 = this.tail.getChild("tail2");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition p_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, -6.0F, -6.0F, 12.0F, 11.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 17.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(48, 0).addBox(-6.0F, -5.0F, -5.0F, 12.0F, 10.0F, 9.0F), PartPose.offsetAndRotation(0.0F, 13.0F, -3.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_earL = p_head.addOrReplaceChild("earL", CubeListBuilder.create().texOffs(90, 0).addBox(-1.0F, -3.0F, -0.0F, 3.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(4.0F, -5.0F, -1.0F, 0.0F, 0.0F, 0.25F));
        PartDefinition p_earR = p_head.addOrReplaceChild("earR", CubeListBuilder.create().texOffs(98, 0).addBox(-2.0F, -3.0F, -0.0F, 3.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -5.0F, -1.0F, 0.0F, 0.0F, -0.25F));
        PartDefinition p_pawFL = r.addOrReplaceChild("pawFL", CubeListBuilder.create().texOffs(106, 0).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 2.0F, 3.0F), PartPose.offsetAndRotation(3.0F, 22.0F, -5.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_pawFR = r.addOrReplaceChild("pawFR", CubeListBuilder.create().texOffs(0, 23).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 2.0F, 3.0F), PartPose.offsetAndRotation(-3.0F, 22.0F, -5.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_pawBL = r.addOrReplaceChild("pawBL", CubeListBuilder.create().texOffs(12, 23).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 2.0F, 3.0F), PartPose.offsetAndRotation(4.0F, 22.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_pawBR = r.addOrReplaceChild("pawBR", CubeListBuilder.create().texOffs(24, 23).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 2.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, 22.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_tail = r.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(36, 23).addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 5.0F), PartPose.offsetAndRotation(0.0F, 19.0F, 6.0F, -0.4F, 0.0F, 0.0F));
        PartDefinition p_tail2 = p_tail.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(52, 23).addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 5.0F, -0.9F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 64);
    }

    @Override
    public void setupAnim(CathPalug e, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * 0.017453292F;
        this.head.xRot = headPitch * 0.017453292F;
        float s = Mth.cos(limbSwing * 0.7F) * 0.9F * limbSwingAmount;
        this.pawFL.xRot = s; this.pawBR.xRot = s; this.pawFR.xRot = -s; this.pawBL.xRot = -s;
        this.tail.yRot = Mth.sin(ageInTicks * 0.12F) * 0.35F;
        this.tail2.yRot = Mth.sin(ageInTicks * 0.12F + 1.0F) * 0.4F;
        this.earL.zRot = 0.25F + Mth.sin(ageInTicks * 0.05F) * 0.05F;
        this.earR.zRot = -0.25F - Mth.sin(ageInTicks * 0.05F) * 0.05F;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
