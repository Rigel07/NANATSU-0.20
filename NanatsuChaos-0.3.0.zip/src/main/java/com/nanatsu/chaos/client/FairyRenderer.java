package com.nanatsu.chaos.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.nanatsu.chaos.Fairy;
import com.nanatsu.chaos.NanatsuChaos;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class FairyRenderer extends MobRenderer<Fairy, FairyModel> {
    static final ResourceLocation TEX = new ResourceLocation(NanatsuChaos.MODID, "textures/entity/fairy.png");

    public FairyRenderer(EntityRendererProvider.Context c) {
        super(c, new FairyModel(c.bakeLayer(FairyModel.LAYER)), 0.2f);
    }

    @Override
    public ResourceLocation getTextureLocation(Fairy e) { return TEX; }

    @Override
    protected void scale(Fairy e, PoseStack ps, float pt) {
        float s = e.isKing() ? 1.0f : 0.6f;
        ps.scale(s, s, s);
    }
}
