package com.nanatsu.chaos.client;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.function.Function;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

/** Render humanoide generico (caballeros, Escanor, hadas, ilusiones). */
public class HumanRenderer<T extends Mob> extends HumanoidMobRenderer<T, HumanoidModel<T>> {
    private final Function<T, ResourceLocation> tex;
    private final Function<T, Float> scale;

    public HumanRenderer(EntityRendererProvider.Context c, Function<T, ResourceLocation> tex, Function<T, Float> scale, boolean armor) {
        super(c, new HumanoidModel<>(c.bakeLayer(ModelLayers.PLAYER)), 0.4f);
        this.tex = tex;
        this.scale = scale;
        if (armor) {
            this.addLayer(new HumanoidArmorLayer<>(this,
                    new HumanoidModel<>(c.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                    new HumanoidModel<>(c.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                    c.getModelManager()));
        }
    }

    @Override
    public ResourceLocation getTextureLocation(T e) {
        return tex.apply(e);
    }

    @Override
    protected void scale(T e, PoseStack ps, float pt) {
        float s = scale.apply(e);
        ps.scale(s, s, s);
    }
}
