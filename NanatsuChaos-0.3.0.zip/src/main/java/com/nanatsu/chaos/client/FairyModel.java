package com.nanatsu.chaos.client;

import com.nanatsu.chaos.NanatsuChaos;
import com.nanatsu.chaos.Fairy;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo propio generado a mano (sin moldes de vanilla). */
public class FairyModel extends EntityModel<Fairy> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(NanatsuChaos.MODID, "fairy"), "main");
    private final ModelPart root;
    public final ModelPart head;
    public final ModelPart hair;
    public final ModelPart hairB;
    public final ModelPart body;
    public final ModelPart armL;
    public final ModelPart armR;
    public final ModelPart legL;
    public final ModelPart legR;
    public final ModelPart wingL1;
    public final ModelPart wingL2;
    public final ModelPart wingR1;
    public final ModelPart wingR2;

    public FairyModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.hair = this.head.getChild("hair");
        this.hairB = this.head.getChild("hairB");
        this.body = root.getChild("body");
        this.armL = root.getChild("armL");
        this.armR = root.getChild("armR");
        this.legL = root.getChild("legL");
        this.legR = root.getChild("legR");
        this.wingL1 = root.getChild("wingL1");
        this.wingL2 = root.getChild("wingL2");
        this.wingR1 = root.getChild("wingR1");
        this.wingR2 = root.getChild("wingR2");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition p_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_hair = p_head.addOrReplaceChild("hair", CubeListBuilder.create().texOffs(24, 0).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 2.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_hairB = p_head.addOrReplaceChild("hairB", CubeListBuilder.create().texOffs(0, 12).addBox(-3.0F, 0.0F, 0.0F, 6.0F, 7.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -5.0F, 3.5F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(14, 12).addBox(-1.5F, 0.0F, -1.0F, 3.0F, 5.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 13.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_armL = r.addOrReplaceChild("armL", CubeListBuilder.create().texOffs(24, 12).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(2.5F, 13.5F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_armR = r.addOrReplaceChild("armR", CubeListBuilder.create().texOffs(28, 12).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(-2.5F, 13.5F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_legL = r.addOrReplaceChild("legL", CubeListBuilder.create().texOffs(32, 12).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F), PartPose.offsetAndRotation(0.9F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_legR = r.addOrReplaceChild("legR", CubeListBuilder.create().texOffs(36, 12).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F), PartPose.offsetAndRotation(-0.9F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_wingL1 = r.addOrReplaceChild("wingL1", CubeListBuilder.create().texOffs(40, 12).addBox(0.0F, -9.0F, 0.0F, 7.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(1.0F, 14.0F, 1.5F, 0.0F, 0.4F, 0.3F));
        PartDefinition p_wingL2 = r.addOrReplaceChild("wingL2", CubeListBuilder.create().texOffs(0, 23).addBox(0.0F, 0.0F, 0.0F, 5.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(1.0F, 15.0F, 1.5F, 0.0F, 0.3F, -0.2F));
        PartDefinition p_wingR1 = r.addOrReplaceChild("wingR1", CubeListBuilder.create().texOffs(12, 23).addBox(-7.0F, -9.0F, 0.0F, 7.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, 14.0F, 1.5F, 0.0F, -0.4F, -0.3F));
        PartDefinition p_wingR2 = r.addOrReplaceChild("wingR2", CubeListBuilder.create().texOffs(28, 23).addBox(-5.0F, 0.0F, 0.0F, 5.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, 15.0F, 1.5F, 0.0F, -0.3F, 0.2F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(Fairy e, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * 0.017453292F;
        this.head.xRot = headPitch * 0.017453292F;
        float f = Mth.sin(ageInTicks * 0.9F) * 0.6F;
        this.wingL1.zRot = 0.3F + f; this.wingL2.zRot = -0.2F + f * 0.7F;
        this.wingR1.zRot = -0.3F - f; this.wingR2.zRot = 0.2F - f * 0.7F;
        this.legL.xRot = Mth.cos(limbSwing * 0.6F) * 0.8F * limbSwingAmount;
        this.legR.xRot = -Mth.cos(limbSwing * 0.6F) * 0.8F * limbSwingAmount;
        this.armL.xRot = -this.legL.xRot * 0.8F; this.armR.xRot = -this.legR.xRot * 0.8F;
        this.armL.zRot = 0.15F + Mth.sin(ageInTicks * 0.1F) * 0.05F; this.armR.zRot = -0.15F - Mth.sin(ageInTicks * 0.1F) * 0.05F;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
