package com.nanatsu.chaos.client;

import com.nanatsu.chaos.NanatsuChaos;
import com.nanatsu.chaos.CathPalug;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo propio generado a mano (sin moldes de vanilla). */
public class CathBossModel extends EntityModel<CathPalug> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(NanatsuChaos.MODID, "cath_boss"), "main");
    private final ModelPart root;
    public final ModelPart chest;
    public final ModelPart body;
    public final ModelPart head;
    public final ModelPart snout;
    public final ModelPart jaw;
    public final ModelPart tU1;
    public final ModelPart tU2;
    public final ModelPart tL1;
    public final ModelPart tL2;
    public final ModelPart tongue;
    public final ModelPart earL;
    public final ModelPart earR;
    public final ModelPart tail;
    public final ModelPart t1;
    public final ModelPart t2;
    public final ModelPart t3;
    public final ModelPart legFR;
    public final ModelPart legFL;
    public final ModelPart legBR;
    public final ModelPart legBL;

    public CathBossModel(ModelPart root) {
        this.root = root;
        this.chest = root.getChild("chest");
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.snout = this.head.getChild("snout");
        this.jaw = this.head.getChild("jaw");
        this.tU1 = this.snout.getChild("tU1");
        this.tU2 = this.snout.getChild("tU2");
        this.tL1 = this.jaw.getChild("tL1");
        this.tL2 = this.jaw.getChild("tL2");
        this.tongue = this.jaw.getChild("tongue");
        this.earL = this.head.getChild("earL");
        this.earR = this.head.getChild("earR");
        this.tail = root.getChild("tail");
        this.t1 = this.tail.getChild("t1");
        this.t2 = this.tail.getChild("t2");
        this.t3 = this.tail.getChild("t3");
        this.legFR = root.getChild("legFR");
        this.legFL = root.getChild("legFL");
        this.legBR = root.getChild("legBR");
        this.legBL = root.getChild("legBL");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition p_chest = r.addOrReplaceChild("chest", CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, -6.0F, -6.0F, 12.0F, 12.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 9.0F, -5.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(44, 0).addBox(-4.5F, -5.0F, -6.0F, 9.0F, 10.0F, 14.0F), PartPose.offsetAndRotation(0.0F, 10.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(90, 0).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 7.0F, 6.0F), PartPose.offsetAndRotation(0.0F, 7.0F, -11.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_snout = p_head.addOrReplaceChild("snout", CubeListBuilder.create().texOffs(0, 24).addBox(-3.0F, -1.0F, -5.0F, 6.0F, 2.0F, 5.0F), PartPose.offsetAndRotation(0.0F, 1.0F, -6.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_jaw = p_head.addOrReplaceChild("jaw", CubeListBuilder.create().texOffs(22, 24).addBox(-3.0F, 0.0F, -5.0F, 6.0F, 2.0F, 5.0F), PartPose.offsetAndRotation(0.0F, 2.0F, -5.5F, 0.5F, 0.0F, 0.0F));
        PartDefinition p_tU1 = p_snout.addOrReplaceChild("tU1", CubeListBuilder.create().texOffs(44, 24).addBox(-2.5F, 1.0F, -4.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_tU2 = p_snout.addOrReplaceChild("tU2", CubeListBuilder.create().texOffs(48, 24).addBox(1.5F, 1.0F, -4.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_tL1 = p_jaw.addOrReplaceChild("tL1", CubeListBuilder.create().texOffs(52, 24).addBox(-2.5F, -2.0F, -4.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_tL2 = p_jaw.addOrReplaceChild("tL2", CubeListBuilder.create().texOffs(56, 24).addBox(1.5F, -2.0F, -4.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_tongue = p_jaw.addOrReplaceChild("tongue", CubeListBuilder.create().texOffs(60, 24).addBox(-1.0F, 0.0F, -9.0F, 2.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(0.0F, 1.0F, -4.0F, 0.35F, 0.0F, 0.0F));
        PartDefinition p_earL = p_head.addOrReplaceChild("earL", CubeListBuilder.create().texOffs(82, 24).addBox(-1.0F, -14.0F, -1.0F, 2.0F, 14.0F, 2.0F), PartPose.offsetAndRotation(3.0F, -4.0F, -1.0F, 0.6F, 0.0F, 0.5F));
        PartDefinition p_earR = p_head.addOrReplaceChild("earR", CubeListBuilder.create().texOffs(90, 24).addBox(-1.0F, -14.0F, -1.0F, 2.0F, 14.0F, 2.0F), PartPose.offsetAndRotation(-3.0F, -4.0F, -1.0F, 0.6F, 0.0F, -0.5F));
        PartDefinition p_tail = r.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(98, 24).addBox(-2.0F, -2.0F, 0.0F, 4.0F, 4.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 8.0F, 12.0F, -0.4F, 0.0F, 0.0F));
        PartDefinition p_t1 = p_tail.addOrReplaceChild("t1", CubeListBuilder.create().texOffs(0, 40).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 8.0F, -0.3F, -0.7F, 0.0F));
        PartDefinition p_t2 = p_tail.addOrReplaceChild("t2", CubeListBuilder.create().texOffs(24, 40).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 8.0F, -0.3F, 0.0F, 0.0F));
        PartDefinition p_t3 = p_tail.addOrReplaceChild("t3", CubeListBuilder.create().texOffs(48, 40).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 8.0F, -0.3F, 0.7F, 0.0F));
        PartDefinition p_legFR = r.addOrReplaceChild("legFR", CubeListBuilder.create().texOffs(72, 40).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 11.0F, 5.0F), PartPose.offsetAndRotation(-4.5F, 13.0F, -8.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_legFL = r.addOrReplaceChild("legFL", CubeListBuilder.create().texOffs(92, 40).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 11.0F, 5.0F), PartPose.offsetAndRotation(4.5F, 13.0F, -8.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_legBR = r.addOrReplaceChild("legBR", CubeListBuilder.create().texOffs(0, 56).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 11.0F, 5.0F), PartPose.offsetAndRotation(-4.0F, 13.0F, 7.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p_legBL = r.addOrReplaceChild("legBL", CubeListBuilder.create().texOffs(20, 56).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 11.0F, 5.0F), PartPose.offsetAndRotation(4.0F, 13.0F, 7.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(CathPalug e, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * 0.017453292F;
        this.head.xRot = headPitch * 0.017453292F;
        float s = Mth.cos(limbSwing * 0.6F) * 0.9F * limbSwingAmount;
        this.legFR.xRot = s; this.legBL.xRot = s; this.legFL.xRot = -s; this.legBR.xRot = -s;
        this.jaw.xRot = 0.55F + Mth.sin(ageInTicks * 0.12F) * 0.15F;
        this.tongue.xRot = 0.35F + Mth.sin(ageInTicks * 0.2F) * 0.1F;
        this.t1.yRot = -0.7F + Mth.sin(ageInTicks * 0.1F) * 0.25F;
        this.t2.yRot = Mth.sin(ageInTicks * 0.1F + 1.5F) * 0.25F;
        this.t3.yRot = 0.7F + Mth.sin(ageInTicks * 0.1F + 3.0F) * 0.25F;
        this.earL.zRot = 0.5F + Mth.sin(ageInTicks * 0.08F) * 0.1F;
        this.earR.zRot = -0.5F - Mth.sin(ageInTicks * 0.08F) * 0.1F;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
