package com.nanatsu.chaos.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.nanatsu.chaos.CathPalug;
import com.nanatsu.chaos.NanatsuChaos;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Cath Palug: dos modelos propios (gatito rechoncho y bestia del Caos). */
public class CathRenderer extends MobRenderer<CathPalug, EntityModel<CathPalug>> {
    static final ResourceLocation KITTEN = new ResourceLocation(NanatsuChaos.MODID, "textures/entity/cath_kitten.png");
    static final ResourceLocation BOSS = new ResourceLocation(NanatsuChaos.MODID, "textures/entity/cath_boss.png");
    private final EntityModel<CathPalug> kitten;
    private final EntityModel<CathPalug> boss;

    public CathRenderer(EntityRendererProvider.Context c) {
        super(c, new CathKittenModel(c.bakeLayer(CathKittenModel.LAYER)), 0.6f);
        this.kitten = this.model;
        this.boss = new CathBossModel(c.bakeLayer(CathBossModel.LAYER));
    }

    @Override
    public void render(CathPalug e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        this.model = e.isBoss() ? boss : kitten;
        this.shadowRadius = e.isBoss() ? 2.5f : 0.6f;
        super.render(e, yaw, pt, ps, buf, light);
    }

    @Override
    public ResourceLocation getTextureLocation(CathPalug e) { return e.isBoss() ? BOSS : KITTEN; }

    @Override
    protected void scale(CathPalug e, PoseStack ps, float pt) {
        if (e.isBoss()) ps.scale(1.5f, 1.5f, 1.5f);
    }
}
